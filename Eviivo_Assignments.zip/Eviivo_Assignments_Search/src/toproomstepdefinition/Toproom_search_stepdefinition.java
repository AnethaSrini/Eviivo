
package toproomstepdefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Toproom_search_stepdefinition {

	
	WebDriver driver;
	@Before
	public void test_setup()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver = new ChromeDriver();
	
	}
	
	@After
	
public void testclose()
	{
		//driver.quit();
		
	}
	
@Given("^the toprooms web application$")
public void the_toprooms_web_application()  {
	
	  driver.get("http://www.toprooms.com");

    
}

@When("^I enter \"([^\"]*)\" and click search$")
public void i_enter_and_click_search(String arg1)  {
	
	//search based on the destination
	driver.findElement(By.id("eviivo-search-destination")).sendKeys(arg1);
	  
	  
	 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	 
	  WebElement select = driver.findElement(By.className("mod-search-filters-outer"));
	  List<WebElement> options =driver.findElements(By.xpath("//ul[@class='ui-autocomplete ui-front ui-menu.ui-widget ui-widget-content']//li"));
	  
	  for (int i=0;i<options.size();i++)
	  {
		 WebElement elt= options.get(i);
		 String str = elt.getText();
		 System.out.println(str);
		 if(str.contentEquals(arg1));
		 {
			 elt.click();
			 break;
		 }
		 
		  
	  }
	  
	  
	  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  
	  //driver.findElement(By.id("eviivo-search-start-date")).click();
	  driver.findElement(By.id("eviivo-search-button")).click();
	  //Select the date and search based on destination
	  driver.findElement(By.id("eviivo-search-start-date")).click();
	  driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[4]/td[4]/a")).click();
	  driver.findElement(By.id("eviivo-search-end-date")).click();
	  driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[5]/td[6]/a")).click();
	  driver.findElement(By.id("eviivo-search-button")).click();
	

   
}

@Then("^I should see some rooms on the \"([^\"]*)\"$")
public void i_should_see_some_rooms_on_the(String arg1)  {
   
	//Verify the availability in the search result page
	  if(driver.getPageSource().contains(arg1))
	  {
		  System.out.println("Test Pass");
		}

		else
		{
			 System.out.println("Test Fail");
		}
	  


    
}

}
